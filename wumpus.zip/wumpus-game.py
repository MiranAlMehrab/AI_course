import os
import pygame
from pygame.locals import *
from random import randrange

###########Global variable ##################
list_of_caves = []
agent_image = pygame.image.load('agent.jpg')
wumpus_image = pygame.image.load('wumpus.jpg')
gold_image = pygame.image.load('gold.jpg')
pit_image = pygame.image.load('pit.jpg')
agent_position = []

######Initialize screen of game window ####################

game_window_width = 1000 
game_window_height = 700

pygame.init()
screen = pygame.display.set_mode((game_window_width, game_window_height))
pygame.display.set_caption('Wumpus World')


def event_handler():    
    for event in pygame.event.get():
        #print(event)
        if event.type == QUIT or (
             event.type == KEYDOWN and (
              event.key == K_ESCAPE or
              event.key == K_q
             )):    
            pygame.quit() #quit from pygame
            quit() #quit from py system


def draw_map():

        rect_width = 60
        rect_height = 60
        color = (40, 40, 240)                
        left_padding = 200
        top_padding = 25

        for j in range(0,10):
                for i in range(0,10):

                        pos_x = (i*65)+left_padding
                        pos_y = (j*65)+top_padding
                        pygame.draw.rect(screen,color,pygame.Rect(pos_x, pos_y, rect_width, rect_height))

                        cave_index = [pos_x,pos_y]
                        list_of_caves.append(cave_index)




def add_environments_elements():
        all_cave_item = []
        cave_item = [gold_image,15]
        all_cave_item.append(cave_item)
        cave_item = [wumpus_image,52]
        all_cave_item.append(cave_item)
        cave_item = [gold_image,77]
        all_cave_item.append(cave_item)
        cave_item = [wumpus_image,85]
        all_cave_item.append(cave_item)
        cave_item = [agent_image,0]
        all_cave_item.append(cave_item)
        cave_item = [pit_image,20]
        all_cave_item.append(cave_item)
        
        for cave in all_cave_item:
                image = cave[0]
                index_x = list_of_caves[cave[1]][0]
                index_y = list_of_caves[cave[1]][1]
                
                screen.blit(image,(index_x,index_y))
                if(image == agent_image):
                        agent_position.append([index_x,index_y])


def keep_map_alive_and_update():
        while True:
                event_handler()
                move_agent(list_of_caves[randrange(100)][0],list_of_caves[randrange(100)][1])
                pygame.display.update()

################agent movement ##################
def move_agent(x,y):
        print('x: ',x)
        screen.blit(agent_image,(x,y))
        agent_position.append([x,y])
        #pygame.display.update()



########################main function from where the prgram starts#############################


def main():
        draw_map()
        add_environments_elements()
        

        keep_map_alive_and_update()
        






if __name__ == '__main__':
        main()